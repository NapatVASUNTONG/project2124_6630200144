<template>
    <div class="card my-2">
        <div class="card-body bg-info bg-opacity-10">
            <h5 class="card-title">รหัสนิสิต {{students.id }}</h5>
            <div class="card-sub-title">ชื่อ สกุล {{students.name }}</div>
            <div class="cart-text">สาขาวิชา {{students.major }} ชั้นปีที่ {{students.yr }}</div>
        </div>
    </div>
    
    <button class="btn btn-success" @click="editDetail(stdID)">
        แก้ไขข้อมูล
    </button>
</template>

<script>
export default {
    name: 'StdDetail',
    props:['stdID'],
    data(){
        return {
            students:[]

        }
    },
    mounted(){
        fetch('http://localhost:3000/students/'+ this.stdID)
        .then(res=>res.json())
        .then(data=>this.students = data)
        .catch(err=>console.log(err.message))
    },
    methods:{
        editDetail(theID) {
            this.$emit('edit', theID)
        }
    }
}
</script>

<style>

</style>