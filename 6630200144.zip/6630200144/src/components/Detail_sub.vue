<template>
    <ul class="list-group">
        <li v-for="(sub, index) in students" :key="index" class="list-group-item">
            <div>
                <h5>{{ sub.id }} - {{ sub.name_En_suB }} - {{ sub.name_Th_suB }}</h5>
                <p>หน่วยกิต: {{ sub.Credit }} - เกรด: {{ sub.Grade }} - ปีการศึกษา: {{ sub.Year_for_std }} - เทอม: {{ sub.Term }}</p>
                <button class="btn btn-danger" @click="delDetail(sub.id)">
                    ลบข้อมูล
                </button>
            </div>
        </li>
    </ul>
    <div class="m-2" v-if="showEdit">
        <StdEdit :stdId=numId @edit="showEdit" @delete="reload" />
    </div>
  </template>
  
  <script>
  import StdEdit from './StdEdit.vue'
  
  export default {
    name: 'StdDetail',
    props: ['stdId'],
    components: {
        StdEdit
    },
    data() {
        return {
            students: [],
            showEdit: false,
            numId: this.stdId
        }
    },
    mounted() {
        fetch('http://localhost:3000/Extra_information/')
            .then(res => res.json())
            .then(data => this.students = data)
            .catch(err => console.log(err.message))
    },
    methods: {
        editDetail(theID) {
            this.$emit('edit', theID)
        },
        delDetail(theId) {
            fetch('http://localhost:3000/Extra_information/' + theId, {
                method: 'DELETE'
            })
                .then(this.$emit('delete'))
                .catch()
        },
        toggleEdit() {
            this.showEdit = !this.showEdit
        }
    }
  }
  </script>
  
  <style scoped>
  .list-group {
      margin-top: 20px;
  }
  
  .list-group-item {
      display: flex;
      justify-content: space-between;
      align-items: center;
      padding: 1rem;
      margin-bottom: 10px;
  }
  
  .btn-danger {
      margin-left: 10px;
  }
  </style>
  