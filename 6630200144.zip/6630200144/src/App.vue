<template>
  <nav class="navbar navbar-expand-lg bg-dark">
    <i class="bi bi-8-square-fill"></i>
    <div class="container-fluid">
      <a class="navbar-brand text-light"  href="#">Portfolio</a>
      <img src="./assets/image2.jpg" alt="Image 2" class="img-fluid mt-3">
      <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNavDropdown"
        aria-controls="navbarNavDropdown" aria-expanded="false" aria-label="Toggle navigation">
        <span class="navbar-toggler-icon"></span>
      </button>
      <div class="collapse navbar-collapse justify-content-end" id="navbarNavDropdown">
        <ul class="navbar-nav">
        </ul>
      </div>
    </div>
  </nav>

  <div class="container">
    <div class="content">
      <img src="./assets/image1.jpg" alt="Image 1" class="img-fluid mt-3">

      <h1 class="mt-3 text-dark">{{ name_En }}</h1>
      <br>
      <br>
      <br>
      <h4 class="text-dark">{{ name_Th }}</h4>
      <h4 class="text-dark">ประวัติ : {{ History }}</h4>
      <h4 class="text-dark">งานอดิเรก : {{ OG_hobby }}</h4>

      <div class="m-2" v-if="showaddsub">
        <addsub ref="" />
      </div>

      <!-- <div class="m-2" v-if="showDetail_sub">
          <Detail_sub />
        </div> -->



      <h4 class="mt-3 text-dark">Major : Computer Science</h4>
      <h4 class="text-dark">ID : {{ id }}</h4>


      <button class="btn btn-dark" @click="toggleList()">เปิด/ปิดการดูเกรด</button>
      <span class="mx-2"></span>
      <button class="btn btn-dark" @click="toggleAdd()">เพิ่มข้อมูล</button>


      <div class="m-2" v-if="showAdd_sub">
        <Add_sub />
      </div>

      <div class="m-2" v-if="showDetail_sub">
        <Detail_sub @delete="reload()" />
      </div>

    </div>
  </div>


</template>

<script>
import Add_sub from './components/Add_sub.vue';
import Detail_sub from './components/Detail_sub.vue';

export default {
  name: 'App',
  components: {
    Detail_sub, Add_sub
  },
  data() {
    return {
      id: "6630200144",
      name_En: "Napat Vasuntong",
      name_Th: "ณภัทร วสันต์ทอง",
      major: "CS",
      yr: 2,
      History: "โรงเรียนสมัยมัธยม : โรงเรียนฤทธิยะวรรณาลัย",
      OG_hobby: "เล่นเกม ออกแบบเกม",
      showDetail_sub: true,
      showAdd_sub: false
    }
  },
  methods: {
    toggleList() {
      this.showDetail_sub = !this.showDetail_sub
      this.showAdd_sub = false
    },
    toggleAdd() {
      this.showAdd_sub = !this.showAdd_sub
      this.showDetail_sub = false
    },
    reload() {
      this.showDetail_sub = !this.showDetail_sub
    }
  }

}
</script>

<style>
/* Navbar */
.navbar {
  background-color: #343a40; /* เปลี่ยนสีพื้นหลังของ Navbar */
}

.navbar-brand {
  font-size: 1.5rem; /* ปรับขนาดตัวหนังสือของ Navbar Brand */
}

.navbar-toggler {
  border-color: rgba(255, 255, 255, 0.5); /* เปลี่ยนสีเส้นขอบของปุ่ม Toggle Navbar */
}

.navbar-toggler-icon {
  background-image: url("data:image/svg+xml,%3csvg viewBox='0 0 30 30' xmlns='http://www.w3.org/2000/svg'%3e%3cpath stroke='rgba%2812555,255,255,.5%29' stroke-width='2' stroke-linecap='round' stroke-miterlimit='10' d='M4 7h22M4 15h22M4 23h22'/%3e%3c/svg%3e"); /* เปลี่ยนสีไอคอน Navbar Toggler */
}

/* Content */
.content {
  margin-top: 20px; /* ปรับระยะขอบบนของเนื้อหา */
}

.text-primary {
  color: #007bff; /* เปลี่ยนสีข้อความ Primary */
}

.text-dark {
  color: #000000; /* เปลี่ยนสีข้อความ Blue 100 */
}

.text-opacity-50 {
  opacity: 0.5; /* ปรับค่าความทึบของข้อความ */
}

.btn-warning {
  background-color: #ffc107; /* เปลี่ยนสีปุ่ม Warning */
  border-color: #ffc107; /* เปลี่ยนสีเส้นขอบปุ่ม Warning */
}

.btn-info {
  background-color: #17a2b8; /* เปลี่ยนสีปุ่ม Info */
  border-color: #17a2b8; /* เปลี่ยนสีเส้นขอบปุ่ม Info */
}

.btn-warning,
.btn-info {
  color: #fff; /* เปลี่ยนสีของข้อความบนปุ่ม */
}

/* Container */
.container {
  margin: 20px;
  padding: 20px;
  border: 1px solid #dee2e6; /* เพิ่มเส้นขอบ Container */
  border-radius: 10px; /* ปรับรูปร่าง Container เป็นมนตรีวงกลม */
  box-shadow: 0 4px 6px rgba(0, 0, 0, 0.1); /* เพิ่มเงาให้ Container */
}
</style>